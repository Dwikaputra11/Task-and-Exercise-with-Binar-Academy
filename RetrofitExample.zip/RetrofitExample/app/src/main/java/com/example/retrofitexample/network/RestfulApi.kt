package com.example.retrofitexample.network

import com.example.retrofitexample.Car
import com.example.retrofitexample.model.ResponseDataCarItem
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST

interface RestfulApi {

    @GET("admin/car")
    fun getAllCar() : Call<List<ResponseDataCarItem>>

    @POST("admin/car")
    fun postCar(@Body carItem: Car)
}