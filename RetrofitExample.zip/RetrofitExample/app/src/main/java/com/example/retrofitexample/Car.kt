package com.example.retrofitexample

data class Car(val name: String, val category: String,val status: Boolean, val price: Int,val image: String)
