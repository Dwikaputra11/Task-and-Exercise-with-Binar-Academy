package com.example.retrofitexample.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.retrofitexample.model.ResponseDataCarItem
import com.example.retrofitexample.network.RetrofitClient
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ViewModelCar: ViewModel() {
    private var liveDataCar: MutableLiveData<List<ResponseDataCarItem>> = MutableLiveData()

    @JvmName("getLiveDataCar1")
    fun getLiveDataCar():MutableLiveData<List<ResponseDataCarItem>>{
        return liveDataCar
    }

    fun callApiCar(){
        RetrofitClient.instance.getAllCar()
            .enqueue(object : Callback<List<ResponseDataCarItem>>{
                override fun onResponse(
                    call: Call<List<ResponseDataCarItem>>,
                    response: Response<List<ResponseDataCarItem>>
                ) {
                    if(response.isSuccessful){
                        liveDataCar.postValue(response.body())
                    }else{
                        liveDataCar.postValue(null)
                    }
                }

                override fun onFailure(call: Call<List<ResponseDataCarItem>>, t: Throwable) {
                    TODO("Not yet implemented")
                }

            })
    }
}