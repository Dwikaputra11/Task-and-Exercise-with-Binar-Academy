package com.example.retrofitexample.model


import com.google.gson.annotations.SerializedName

class ResponseDataCar : ArrayList<ResponseDataCarItem>()